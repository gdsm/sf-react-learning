interface Person {
  name: string;
  age: number;
  location: string;
}

const person: Person = {
  name: 'Alice',
  age: 30,
  location: 'New York',
};

// Get the keys of the Person interface
type PersonKeys = keyof Person; // "name" | "age" | "location"

// Get the type of the "name" property of the Person interface
type PersonNameType = typeof person.name; // string

// Create a function that returns a value from an object based on a key
// function getValue<T extends object, K extends keyof T>(obj: T, key: K): T[K] {
//   return obj[key];
// }

function getValue<T extends Person, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key];
}

const personName = getValue(person, 'age'); // "Alice"
const personAge = getValue(person, 'age'); // 30
const personLocation = getValue(person, 'location'); // "New York"
const invalidKey = getValue(person, 'invalid'); // Compile error: Argument of type '"invalid"' is not assignable to parameter of type '"name" | "age" | "location"'
