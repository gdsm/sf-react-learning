
function printArray<T>(array: T[]): void {
  for (let item of array) {
    console.log(item);
  }
}

printArray<string>(["apple", "banana", "orange"]); // Output: "apple", "banana", "orange"
printArray<number>([1, 2, 3, 4, 5, ]); // Output: 1, 2, 3, 4, 5

// printArray<PersonType>([])
