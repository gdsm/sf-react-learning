
type BinaryOperation = (a: number, b: number) => number;

function add(a: number, b: number): number {
  return a + b;
}

const subtract:BinaryOperation = (a: number, b: number): number => {
  return a - b;
}

// inline type expression

// Define a function that takes an operation function as an argument
function calculate(operation: (a: number, b: number) => number, a: number, b: number): number {
  return operation(a, b);
}

// Call the calculate function with an inline operation function expression
const result = calculate((a: number, b: number): number => {
  return a + b;
}, 10, 5);

console.log(result); // Output: 15
