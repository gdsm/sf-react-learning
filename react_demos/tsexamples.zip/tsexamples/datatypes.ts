(function(){
// Type annotations
// boolean
let isTrue: boolean = true;

// Type inference
let name = "Alice";
let age: number = 30;
let message = `${name} is ${age} years old.`;

// number
let decimal: number = 6;

// string
let hello: string = "Hello";
let greeting: string = `${hello}, Gaurav!`;

// array
type numberType = number;
let numbers: numberType[] = [1, 2, 3, 4, 5];
let names: string[] = ["Alice", "Bob", "Charlie"];
let mixedArray: (string | number)[] = ["Hello", 123, "world"];

// tuple
let tuple: [string, number] = ["hello", 123];

// Union types
type ColorUnionType = 'red' | 'green' | 'blue';

function printColor(color: ColorUnionType) {
  console.log(`Color is ${color}.`);
}

function printId(id: number | string) {
  console.log(`ID is ${id}.`);
}

// enum
enum Color {
  Red = "#f00",
  Green = "#0f0",
  Blue = "#00f",
}
let myColor: Color = Color.Red;

console.log(myColor)

// any
let myVariable: any = "hello";
myVariable = 123;
myVariable = [1,2,3];

// void
type messageType = 'Error1' | 'Error2'
function logMessage(message: messageType): void {
  console.log(message);
}

type logFunction = (message: string) => void;

const logMessage1: logFunction = (message: string): number => {
  console.log(message);
  return 10;
}

logMessage1('myname');

// null and undefined
let nullValue: null = null;
let undefinedValue: undefined = undefined;

// object
let myObject : object = { name: "Alice", age: 30 };
// You cannot access the properties of an `object` type
// console.log(myObject.name); // Error: Property 'name' does not exist on type 'object'.
// You need to use type assertion or interface to access the properties
interface Person {
  name: string;
  age: number;
}

type PersonType = {
  name: string;
  age: number;
}

let myPerson: PersonType = { name: "Alice", age: 'null' };
let myPerson1: PersonType = { name: "Alice", age: 30 };
console.log(myPerson.name); // Alice

// unknown
// function f1(a: unknown) {
//   if()
//   a.b(); // OK
//   a.toString();
// }
function f2(a: any) {
  if(typeof a === 'number'){
    a.toString();
  } 
  // a.toString();
}


// never

function fn(x: string | number) {
  if (typeof x === "string") {
    // do something
  } else if (typeof x === "number") {
    // do something else
  } else {
    x; // has type 'never'!
  }
}

function error(message: string): never {
 
  // throw new Error(message);
  // return;

  // return "Error"
}

})();