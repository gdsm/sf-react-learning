
function printMessage(message: string | number) {
  if (typeof message === 'string') {
    console.log(message.push());
  } else if(typeof message === 'number'){

  } else {
    console.log(`The message is: ${message}`);
  }
}

printMessage("hello"); // Output: "HELLO"
printMessage(42); // Output: "The message is: 42"
