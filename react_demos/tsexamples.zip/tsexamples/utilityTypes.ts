// Define an interface for a user object
interface User {
  name: string;
  age: number;
  email?: string;
}

// Define a type using the built-in Pick utility type
type UserSummary = Pick<User, 'name' | 'email'>;

// Define a function that returns a user object
function createUser(name: string, age: number, email?: string): User {
  return { name, age, email };
}

// Create a new user object with required properties
const requiredUser: Required<User> = { name: 'Alice', age: 30};

// Create a new user object with partial properties
const partialUser: Partial<User> = { name: 'Bob' };

// Call the createUser function and capture the return type
type CreateUserReturnType = ReturnType<typeof createUser>;
const newUser: CreateUserReturnType = createUser('Charlie', 25);

console.log(requiredUser); // Output: { name: 'Alice', age: 30, email: 'alice@example.com' }
console.log(partialUser); // Output: { name: 'Bob' }
console.log(newUser); // Output: { name: 'Charlie', age: 25 }
