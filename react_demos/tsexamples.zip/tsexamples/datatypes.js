(function () {
    // Type annotations
    // boolean
    var isTrue = true;
    // Type inference
    var name = "Alice";
    var age = 30;
    var message = "".concat(name, " is ").concat(age, " years old.");
    // number
    var decimal = 6;
    // string
    var hello = "Hello";
    var greeting = "".concat(hello, ", Gaurav!");
    // array
    var numbers = [1, 2, 3, 4, 5];
    var names = ["Alice", "Bob", "Charlie"];
    var mixedArray = ["Hello", 123, "world"];
    // tuple
    var tuple = ["hello", 123];
    function printColor(color) {
        console.log("Color is ".concat(color, "."));
    }
    function printId(id) {
        console.log("ID is ".concat(id, "."));
    }
    // enum
    var Color;
    (function (Color) {
        Color["Red"] = "#f00";
        Color["Green"] = "#0f0";
        Color["Blue"] = "#00f";
    })(Color || (Color = {}));
    var myColor = Color.Green;
    console.log(myColor);
    // any
    var myVariable = "hello";
    myVariable = 123;
    myVariable = [1, 2, 3];
    // void
    function logMessage(message) {
        console.log(message);
    }
    var logMessage1 = function (message) {
        console.log(message);
        return 10;
    };
    logMessage1('myname');
    // null and undefined
    var nullValue = null;
    var undefinedValue = undefined;
    // object
    var myObject = { name: "Alice", age: 30 };
    var myPerson = { name: "Alice", age: 30 };
    var myPerson1 = { name: "Alice", age: 30 };
    console.log(myPerson.name); // Alice
    // unknown
    function f1(a) {
        a.b(); // OK
    }
    function f2(a) {
        if (typeof a === 'number') {
            a.toString();
        }
        // a.toString();
    }
    // never
    function fn(x) {
        if (typeof x === "string") {
            // do something
        }
        else if (typeof x === "number") {
            // do something else
        }
        else {
            x; // has type 'never'!
        }
    }
    function error(message) {
        throw new Error(message);
        // return "Error"
    }
})();
